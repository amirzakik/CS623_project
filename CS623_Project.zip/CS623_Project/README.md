# CS623_Project
DBMS Project With Geographic Information System (GIS) Analysis

This repo contains a collection of sql queries and geographic data such as maps and spatial data of US cities, US counties and US states.
Data source: https://github.com/opengeos/data ,   https://www.diva-gis.org/gdata

